# Analista José Quipanda — Site

Site estático responsivo em português, inspirado no layout de referência.

## Publicar na Vercel
1. Envie `index.html` para um repositório GitHub.
2. Na Vercel, escolha **Add New → Project** e importe esse repositório.
3. Para este HTML estático, pode manter as configurações padrão e clicar em **Deploy**.

## Antes de publicar
- Substitua a fotografia de perfil provisória pela sua fotografia.
- Os links do YouTube, TikTok e Facebook foram configurados com os URLs fornecidos.
- A newsletter é demonstrativa e ainda não está ligada a um serviço de subscrição.
- Os artigos são demonstrativos e devem ser substituídos por artigos reais com fontes científicas.
